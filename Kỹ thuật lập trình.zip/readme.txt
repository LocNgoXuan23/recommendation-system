- sửa lại phần INCLUDEPATH = "path/Includes/eigen-3.4.0" trong file .pro
- sửa lại đường dẫn file trong file mainwindow.cpp. 
   Y_train_data = getData("path\\some_handled_train_data.txt", N, M);
   Y_test_data = getData("path\\some_handled_test_data.txt", H, M);